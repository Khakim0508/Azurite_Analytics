--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.0
-- Dumped by pg_dump version 13.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE flow_map;
--
-- Name: flow_map; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE flow_map WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1251';


ALTER DATABASE flow_map OWNER TO postgres;

\connect flow_map

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: routes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routes (
    a integer NOT NULL,
    b integer NOT NULL,
    distance double precision,
    CONSTRAINT no_self_loop CHECK ((a <> b))
);


ALTER TABLE public.routes OWNER TO postgres;

--
-- Name: stations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stations (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    country character varying(10) NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL
);


ALTER TABLE public.stations OWNER TO postgres;

--
-- Name: stations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stations_id_seq OWNER TO postgres;

--
-- Name: stations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stations_id_seq OWNED BY public.stations.id;


--
-- Name: vagons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vagons (
    id integer,
    origin integer,
    destination integer,
    last_station integer
);


ALTER TABLE public.vagons OWNER TO postgres;

--
-- Name: stations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stations ALTER COLUMN id SET DEFAULT nextval('public.stations_id_seq'::regclass);


--
-- Data for Name: routes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routes (a, b, distance) FROM stdin;
\.
COPY public.routes (a, b, distance) FROM '$$PATH$$/3003.dat';

--
-- Data for Name: stations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stations (id, name, country, latitude, longitude) FROM stdin;
\.
COPY public.stations (id, name, country, latitude, longitude) FROM '$$PATH$$/3002.dat';

--
-- Data for Name: vagons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vagons (id, origin, destination, last_station) FROM stdin;
\.
COPY public.vagons (id, origin, destination, last_station) FROM '$$PATH$$/3004.dat';

--
-- Name: stations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stations_id_seq', 5024, true);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (a, b);


--
-- Name: stations stations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stations
    ADD CONSTRAINT stations_pkey PRIMARY KEY (id);


--
-- Name: a_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX a_idx ON public.routes USING btree (a);


--
-- Name: b_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX b_idx ON public.routes USING btree (b);


--
-- Name: routes routes_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_a_fkey FOREIGN KEY (a) REFERENCES public.stations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: routes routes_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_b_fkey FOREIGN KEY (b) REFERENCES public.stations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vagons vagons_destination_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vagons
    ADD CONSTRAINT vagons_destination_fkey FOREIGN KEY (destination) REFERENCES public.stations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vagons vagons_last_station_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vagons
    ADD CONSTRAINT vagons_last_station_fkey FOREIGN KEY (last_station) REFERENCES public.stations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vagons vagons_origin_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vagons
    ADD CONSTRAINT vagons_origin_fkey FOREIGN KEY (origin) REFERENCES public.stations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

